package com.example.timeline;

import android.view.View;

public interface ItemClickListener {
        void itemClick(View view, int position);
    }

